BossForge Live: original VecSynIQ SVG source assets.
Source Drive folder: https://drive.google.com/drive/folders/1HlGDDQrPUMo7Fc_8rQumcKpoqmn56G2p
Only source assets and manifest are included.
Do not inline unreviewed SVGs; inspect/sanitize/optimize then compare render outputs before web integration.
Keep originals in source archive rather than shipping them to the web client unoptimized.
